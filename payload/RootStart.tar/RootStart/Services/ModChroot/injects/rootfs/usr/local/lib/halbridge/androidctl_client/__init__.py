"""Debian-side HALBridge client."""
